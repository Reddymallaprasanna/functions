#user deined function
def hi():
    print("hello sir")
hi()
#user defined fun with arg
def sum(x,y):
    print("sum of two numbers is:",x+y)
print("example-1")
a=int(input("Enter the value of A:"))
b=int(input("Enter the value of B:"))
sum(a,b)
#user defined fun with arg
def sum(x,y):
    return x+y
print("example-2")
a=int(input("Enter the value of A:"))
b=int(input("Enter the value of B:"))
print(sum(a,b))
#example-3
def sum(x,y):
    return x+y
print("example-3")
a=int(input("Enter the value of A:"))
b=int(input("Enter the value of B:"))
res=sum(a,b)
print(res)
#default arguments
def power(base,epo):
    return base**epo
print("base and expo")
num=int(input("enter the base"))
print(power(num,3))

#perform more operations
def mult(x,y):
    return x+y,x-y,x*y
print("more opt11")
a=int(input("enter value of A:"))
b=int(input("enter value of B:"))
sum,sub,pro=mult(a,b)
print("sum:",sum)
print("difference:",sub)
print("product:",pro)

#anonumous function lambda
#lambda var: operation
n=int(input("Enter a number:"))
square=lambda n:n*n
print(square(n))